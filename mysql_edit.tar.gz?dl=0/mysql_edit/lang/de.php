<?php

/**
 * German language file - version .1.2
 * 
 */


$this->text['Add_Record'] = 'Neuer Datensatz';
$this->text['Clear_search'] = 'Suche zurücksetzen';
$this->text['Search'] = 'Suche';

$this->text['Go_back'] = 'Zurück ohne Änderung';
$this->text['Save'] = 'Speichern';
$this->text['saved'] = 'gespeichert';
$this->text['Delete'] = 'Löschen';
$this->text['Edit'] = 'Bearbeiten';
$this->text['deleted'] = 'gelöscht';

$this->text['Previous'] = 'Vorherige';
$this->text['Next'] = 'Nächste';

$this->text['Nothing_found'] = 'Nichts gefunden';
$this->text['Check_the_required_fields'] = 'Überprüfe die (gelb hinterlegten) Pflichtfelder';
$this->text['Protect_this_directory_with'] = 'Schütze dieses Verzeichnis per';

?>
