<?php

/**
 * English language file - version .1.2
 * 
 */


$this->text['Add_Record'] = 'Add Record';
$this->text['Clear_search'] = 'Reset search';
$this->text['Search'] = 'Search';

$this->text['Go_back'] = 'Go back';
$this->text['Save'] = 'Save';
$this->text['saved'] = 'Saved';
$this->text['Delete'] = 'Delete';
$this->text['Edit'] = 'Edit';
$this->text['deleted'] = 'deleted';

$this->text['Previous'] = 'Previous';
$this->text['Next'] = 'Next';

$this->text['Nothing_found'] = 'Nothing found';
$this->text['Check_the_required_fields'] = 'Check the required (yellow) fields';
$this->text['Protect_this_directory_with'] = 'Protect this directory with';

?>
