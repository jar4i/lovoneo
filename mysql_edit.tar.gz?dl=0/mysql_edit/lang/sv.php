<?php

/*
 * Swedish language file - version 1.x
 * 
 */

$this->text['Add_Record'] = 'Lägg till';
$this->text['Search'] = 'Sök';
$this->text['Clear_search'] = 'Återställ';

$this->text['Go_back'] = 'Tillbaka';
$this->text['Save'] = 'Spara';
$this->text['saved'] = 'Sparad';
$this->text['Delete'] = 'Tabort';
$this->text['deleted'] = 'Borttagen';
$this->text['Edit'] = 'Redigera';

$this->text['Previous'] = 'Föregående';
$this->text['Next'] = 'Nästa';

$this->text['Nothing_found'] = 'Inget hittat';
$this->text['Check_the_required_fields'] = 'Kontroller obligatoriska (gula) fält';
$this->text['Protect_this_directory_with'] = 'Skydda katalogen med';

?>

