<?php

/**
 * French language file - version .1.2
 * 
 */


$this->text['Add_Record'] = 'Ajouter un enregistrement';
$this->text['Clear_search'] = 'Réinitialiser la recherche';
$this->text['Search'] = 'Rechercher';

$this->text['Go_back'] = 'Revenir';
$this->text['Save'] = 'Enregistrer';
$this->text['saved'] = 'enregistré';
$this->text['Delete'] = 'Supprimer';
$this->text['Edit'] = 'Editer';
$this->text['deleted'] = 'supprimé';

$this->text['Previous'] = 'Précédent';
$this->text['Next'] = 'Suivant';

$this->text['Nothing_found'] = 'Aucun enregistrement trouvé';
$this->text['Check_the_required_fields'] = 'Vérifiez les champs obligatoires (jaunes)';
$this->text['Protect_this_directory_with'] = 'Protégez ce répertoire avec';

?>
